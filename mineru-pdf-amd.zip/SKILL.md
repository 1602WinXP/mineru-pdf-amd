---
name: mineru-pdf-amd
description: |
  Deploy and batch-process PDFs with MinerU on **AMD ROCm GPU (RDNA2/3/4)** via WSL2
  (Ubuntu 22.04). Use when the user wants to: (1) **first-time install** MinerU 3.x +
  ROCm 7.1.1 + vLLM 0.21.1rc0 + PyTorch 2.11.0+rocm7.1 on Windows 11 + WSL2, (2) **batch
  process** PDFs through the local mineru-api, (3) **fix / reproduce** an existing AMD
  install across devices. Do NOT use for: NVIDIA GPUs (use `mineru-batch-pdf` instead),
  native Linux (most of the WSL2 bridging / librocdxg steps are unnecessary), or single-PDF
  one-off runs (use `mineru -p` directly).
status: live
version: v1
date: 2026-07-16
---

# MinerU AMD — ROCm + WSL2 部署与批量解析

**Portable skill**：脚本、补丁、版本矩阵都打包在 skill 目录内。换机器、升级、重装时只
要按本 skill 的 bootstrap 顺序重跑就能复现完整 MinerU + ROCm 环境。

**适用 GPU（gfx → PYTORCH_ROCM_ARCH）**：
- RDNA4 RX 9070/9070 XT/9070 GRE → `gfx1201`
- RDNA3 RX 7900 XTX/XT/GRE → `gfx1100`（实测，教程默认 gfx）
- RDNA3 RX 7800 XT/7700 XT → `gfx1101`
- RDNA3 RX 7600/XT → `gfx1102`（可能需要 `HSA_OVERRIDE_GFX_VERSION=11.0.0`）
- RDNA2 RX 6900/6800/6700 → `gfx1030`（部分需要伪装）

> 教程**不适用** RDNA1（RX 5000/5500/5600 系列），vllm 不支持此架构。

## 触发条件

**应当触发**：
- "AMD 显卡装 MinerU"、"在 WSL2 上跑 ROCm"、"部署 AMD 路径的 MinerU"
- "我有 N 个 PDF 要在 AMD 机器上跑"、"mineru 启动失败 / 编译报错 / GPU 离线"
- "我要换机器 / 升级 ROCm / 重装 vllm"、"为什么 vllm cmake 失败"

**不触发**：
- NVIDIA GPU（用 `mineru-batch-pdf` skill）
- 已经是原生 Linux + AMD 机器（跳过 Step 2-4 的 WSL2 桥接）
- 单个 PDF 简单解析（直接 `mineru -p file.pdf -o out` 即可）

## Skill 自带资源

```
~/.mavis/skills/mineru-pdf-amd/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── bootstrap_install.sh          # 一键安装（按教程 11 步顺序）
│   ├── status.sh                     # 验证环境就绪
│   ├── start_api.sh / stop_api.sh    # 启动 / 停止长连接 mineru-api
│   ├── batch_process.py              # 批量 PDF 处理（SHA256 缓存 + 并发）
│   └── patch-vllm-platform.py        # 教程 9.10 platform patch
│       patch-mineru-miopen.py        # 教程 10.3 MIOpen patch
└── references/
    ├── network-mirrors-amd.md        # 镜像（apt/PyPI/GitHub/HF）
    ├── version-matrix.md             # PyTorch/torchvision/triton/vllm 配对
    └── troubleshooting-amd.md        # 32 项踩坑清单
```

## 三条黄金路径

### 路径 A：首次安装（Ubuntu 22.04 + ROCm 7.1.1）

WSL2 默认是 Ubuntu 24.04，但 **24.04 + ROCm 7.1.1 不可行**（LLVM 20 + ROCm 头文件不兼
容，vllm 编译撞 FP8 错误**无法绕过**）。需要先从 Microsoft Store 装 Ubuntu 22.04。

```bash
# 1. PowerShell（管理员）装 22.04
wsl --install -d Ubuntu-22.04
wsl --set-default Ubuntu-22.04

# 2. 在 Ubuntu 22.04 内执行
bash ~/.mavis/skills/mineru-pdf-amd/scripts/bootstrap_install.sh

# 3. 验证
bash ~/.mavis/skills/mineru-pdf-amd/scripts/status.sh
# 应输出: ROCm 7.1.1 / PyTorch 2.11.0+rocm7.1 / vllm 0.21.1rc0 / MinerU 3.4.4 / GPU 识别
```

**预期总耗时**：2-3 小时（网络慢的话 4-5 小时，主要是 ROCm apt + vllm 编译 30-60 分钟）

### 路径 B：批量处理 PDF（已经装好 MinerU）

```bash
# 1. 启动长连接 API（5-8 秒）
bash ~/.mavis/skills/mineru-pdf-amd/scripts/start_api.sh 8000
# 输出 "API ready: http://127.0.0.1:8000"

# 2. 批量处理
python3 ~/.mavis/skills/mineru-pdf-amd/scripts/batch_process.py \
  /path/to/pdfs/ /path/to/output/ \
  --api-url http://127.0.0.1:8000 \
  --skip-blank \
  --concurrency 2

# 3. 完成后关闭 API
bash ~/.mavis/skills/mineru-pdf-amd/scripts/stop_api.sh
```

### 路径 C：换设备复现 / 修复安装

1. 同步 `~/.mavis/skills/mineru-pdf-amd/` 到新设备
2. 装 Ubuntu 22.04 + 基础依赖（apt）
3. `bash bootstrap_install.sh` 按 11 步重新走
4. 跑 `status.sh` 验证

## 关键版本（锁住不要升级）

| 组件 | 版本 | 理由 |
|---|---|---|
| Ubuntu | 22.04 (jammy) | 24.04 + 7.1.1 不可行 |
| ROCm | 7.1.1 | 教程最稳定组合 |
| Python | 3.13 | 与 PyTorch ROCm 7.1 wheel 匹配 |
| PyTorch | 2.11.0+rocm7.1 | 2.12+ 在 WSL2 闪退 `Found 0 rocprofiler agents` |
| torchvision | 0.26.0+rocm7.1 | 0.25 要 torch 2.10；0.27 要 torch 2.12 |
| triton | triton-rocm 3.6.0 | **不是 pytorch-triton-rocm 3.2.0**（两个不同包名） |
| vLLM | 0.21.1rc0 | 教程指定 GitHub tag |
| MinerU | 3.4.4 | 当前 latest stable |

> ⚠️ **复现第三方要锁版本**。教程说"用 main" = 教程发布时的 main，**不是现在 main**。
> vllm 0.21.1rc0 vs latest main 的 setup.py 差很多（main 缺 HIP_ROOT_DIR，编译失败）。

## 11 步部署流程（详见 `bootstrap_install.sh`）

1. **WSL2 准备** — 装 Ubuntu 22.04，建用户 （此处可自定义用户名，默认用`admin`）（UID 1000），加 sudo/video/render
2. **基础依赖** — apt + deadsnakes PPA + Python 3.13.14 + cmake 4.4.0（pip 装 + 复制到 /usr/local/bin）
3. **ROCm 7.1.1** — AMD 官方源 + aria2c 拉 23 个 dev 包 + 降级 rocminfo 1.0.0.70101
4. **librocdxg** — Windows SDK 10.0.26100.0 + cmake/make 编译 + 装到 /opt/rocm/lib
5. **ROCm dev 包** — hipblas-dev, hiprand-dev, hipsparse-dev, **hipsparselt-dev**,
   hipsolver-dev, hipcub-dev, rocprim-dev, rocthrust-dev, rocblas-dev, rocrand-dev,
   hipfft-dev, hipblaslt
6. **PyTorch 2.11.0+rocm7.1** — torchvision 0.26.0, triton-rocm 3.6.0（aria2c 拉 wheel）
7. **vLLM 0.21.1rc0** — 拉源码 + cmake configure + `ninja -j4`（30-60 min）
8. **vLLM platform patch** — 改 `vllm/platforms/__init__.py` 和 `rocm.py`
9. **MinerU 3.4.4** — `pip install 'mineru[core]'`（用原生 pip，不用 uv）
10. **MIOpen patch** — 改 `predict_rec.py`（imgW 32 对齐 + 批次填充）和 `predict_det.py`（contiguous 检查）
11. **mineru.json** — 配模型路径，**复用 Windows 缓存**：
    `/mnt/c/Users/<user>/.cache/modelscope/models/OpenDataLab--PDF-Extract-Kit-1.0/snapshots/master`

## 网络问题（国内用户必看）

| 源 | 国内直连 | 解决 |
|---|---|---|
| `repo.radeon.com` (apt) | 15 KB/s | `aria2c -j 8 -s 8 -x 8` → 5.7 MB/s |
| `download.pytorch.org` | 慢 | `aria2c -j 4` → 16 MB/s |
| `mirrors.ustc.edu.cn/pypi` | 25-60 MB/s | `pip install -i https://mirrors.ustc.edu.cn/pypi/web/simple/` |
| `github.com` (git clone) | 极慢 | `https://gh-proxy.com/https://github.com/...` → 9.9 MB/s |
| `cmake.org` | 极慢 | `pip install cmake -i USTC mirror` → 25 MB/s |

**关键 git config**（让 FetchContent 走镜像，但**注意 FetchContent 不遵守 insteadOf**）：

```bash
git config --global url."https://gh-proxy.com/https://github.com/".insteadOf "https://github.com/"
# 注：cmake FetchContent 调用 git clone 时**不遵守**此配置
# 必须手动用 gh-proxy 预克隆到 .deps 目录
```

详见 [references/network-mirrors-amd.md](references/network-mirrors-amd.md)

## GPU 性能参考（教程实测）

13 页 PDF 在 RX 9070 (16GB, RDNA4) 上：

| 阶段 | 耗时 | 速度 |
|---|---|---|
| VLM 推理 (Two Step Extraction) | ~6 秒 | 1.98 it/s |
| 版面 + OCR (pipeline) | <1 秒 | 61-71 it/s |
| **13 页总耗时** | **6-7 秒** | — |

7900 XTX (24GB, RDNA3) 实测 10 页 PDF：~2 分钟（含首次冷启动 + kernel 编译）。

## 已知工程权衡

**为什么 subprocess + 长连接 API 而不是 in-process**（4-24GB VRAM 都适用）：

- in-process 一次传 N 个 PDF：`do_parse()` 内存堆积，n 个 PDF 后 OOM
- in-process 分批：CUDA context 不释放，每批都 OOM
- subprocess + 长连接 API：每 PDF 一个独立子进程，CUDA context 自动释放
- **结论**：这是唯一稳定方案，24GB VRAM 仍然推荐

**GPU 0% 占用占 50% 时间**（AMD WSL2）：
- 根因：subprocess 启动 + 模型重载 + CUDA context 重新初始化（每 PDF ~12-15s）
- AMD 比 NVIDIA 多一步：MIOpen kernel 冷启动搜索
- 缓解：教程 12 步 MIOpen 缓存预热（`cache_warmer.py`），首次跑后 1320ms → 30ms

## 调优（24GB VRAM 仍有空间）

1. **并发 `--concurrency 2`** — 一台机器跑 2 个 mineru-cli 子进程
   - 2 进程 ≈ 1.7x 加速（受 GPU 内存带宽限制，不是线性）
   - 4 进程 ≈ 2.0x 加速（边际收益递减，OOM 风险↑）
2. **MIOpen 缓存预热** — 教程 12 步的 `cache_warmer.py`，首次跑全尺寸（944 个 size combo）
3. **模型路径走 NVMe SSD** — `/mnt/c/...` (Windows 盘) 慢，WSL2 native `~/mineru_models/` 快
4. **不开 VLM 后端** — 教程说 RX 9070 VLM 推理 1.98 it/s；如果只要版面+OCR 选 `pipeline` 后端
5. **升级到 VLM**（hybrid-auto-engine）— 需要 MinerU2.5-Pro-2605-1.2B 模型（2.3GB HF 下载）

## 常见错误诊断（精简版）

| 症状 | 原因 | 解决 |
|---|---|---|
| `Found 0 rocprofiler agents` | PyTorch 2.12+ | 降回 2.11.0+rocm7.1 |
| `Failed to find HIP root directory` | setup.py cmake 缺 HIP_ROOT_DIR | `export CMAKE_ARGS="-DHIP_ROOT_DIR=/opt/rocm"` |
| `roc::hipsparselt target not found` | 漏装 `hipsparselt-dev` | `apt install hipsparselt-dev` |
| ninja 编译 `exit 137` | OOM | `ninja -j2`（不是 j4） |
| 第一次跑某尺寸 1-7s，之后 30ms | MIOpen 冷启动 | 跑 `cache_warmer.py` |
| WSL2 重启后 GPU 不可见 | librocdxg / HSA env 没加载 | 跑 `status.sh` 自动设回 |
| `predict_det.py` 缩进报错 | mineru 3.4.4 缩进是 12 spaces 不是 16 | patch 脚本已处理 |

详细 32 项踩坑见 [references/troubleshooting-amd.md](references/troubleshooting-amd.md)

## 输出文件结构

```
<output_dir>/
├── <PDF_stem>/                 # 每个 PDF 一个子目录
│   └── auto/
│       ├── <PDF_stem>.md       # 主交付物
│       ├── *_content_list.json # 结构化内容列表
│       ├── *_layout.pdf       # 版面可视化
│       ├── *_span.pdf         # span 可视化
│       ├── *_model.json       # 模型原始输出
│       ├── *_middle.json      # 中间表示
│       └── images/            # 抽取的图像
├── <PDF_stem2>/...
└── .batch_cache.json          # SHA256 缓存（避免重复处理）
```

## 依赖

- Windows 11 + WSL2
- Ubuntu 22.04.5 LTS (jammy)
- AMD Radeon RX 6000/7000/9000 系列（8GB+ VRAM，16GB+ 推荐）
- 16GB+ RAM
- 50GB+ 磁盘
- cmake 4.0+ / gcc 11+ / Python 3.13 / ninja

## 不做的事

- 不修改 vllm 源码（除教程 9.10 platform patch）
- 不升级 PyTorch 到 2.12+（WSL2 闪退）
- 不升级 vllm 到 main（setup.py bug）
- 不下载新模型（除非用户明确说要）
- 不动 Windows 端 AMD 驱动（教程假设已装）
- 不装 snap（WSL2 永久阻塞，用 Kitware 二进制或 pip 装）
- 不在 24.04 + 7.1.1 上跑（明确不可行）

## 自定义 mineru 安装位置

如 mineru 不在默认路径（`~/mineru_stable`），设环境变量：

```bash
export MINERU_HOME=/path/to/mineru_stable
bash ~/.mavis/skills/mineru-pdf-amd/scripts/status.sh
```

## 相关 skill

- `mineru-batch-pdf` (NVIDIA Windows 草稿) — 本 skill 是其 AMD/WSL2 对应版
- `mavis` — cron / session / memory 管理
