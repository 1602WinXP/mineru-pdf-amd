# Network Mirrors — AMD 路径 (中国国内)

MinerU + ROCm + vLLM 部署会下载约 5-10 GB 数据。国际连接极慢，必须用镜像。

## 实测速度表

| 源 | 国内直连 | 镜像 | 镜像速度 |
|---|---|---|---|
| `repo.radeon.com` (apt) | 15 KB/s | — | 5.7 MB/s（aria2c 加速后） |
| `download.pytorch.org` | 慢 | — | 16 MB/s（aria2c 加速后） |
| `pypi.org` / `mirrors.ustc.edu.cn` | 25-60 MB/s | `https://mirrors.ustc.edu.cn/pypi/web/simple/` | 60 MB/s |
| `github.com` (git clone) | 极慢（10 KB/s） | `https://gh-proxy.com/https://github.com/...` | 9.9 MB/s |
| `cmake.org` | 极慢 | `pip install cmake -i USTC mirror` | 25 MB/s |
| `codeload.github.com` | 21 KB/s | `gh-proxy.com` | 9.9 MB/s |
| HuggingFace | 极慢 | `hf-mirror.com` 或 modelscope | — |
| `huggingface.co` 模型 | 极慢 | `MINERU_MODEL_SOURCE=modelscope` | 5-10 MB/s |

## PyPI 镜像配置

```bash
# 临时
pip install <pkg> -i https://mirrors.ustc.edu.cn/pypi/web/simple/

# 永久（推荐）
mkdir -p ~/.pip
cat > ~/.pip/pip.conf << 'EOF'
[global]
index-url = https://mirrors.ustc.edu.cn/pypi/web/simple/
extra-index-url = https://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.ustc.edu.cn mirrors.aliyun.com
EOF
```

## PyTorch 官方 wheel（不能走 PyPI 镜像）

PyPI 只有 CPU wheel。CUDA / ROCm wheel 必须在 `download.pytorch.org`。

```bash
# 路径模式：https://download.pytorch.org/whl/rocm7.1/{pkg}-{ver}+rocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl
# 注意 + 号在 URL 要 URL-encode 为 %2B
```

**Python 3.13 + Linux x86_64 wheel 直链**（2026-07 当前）：

```text
# torch 2.11.0 + rocm7.1 (5.8 GB)
https://download.pytorch.org/whl/rocm7.1/torch-2.11.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl

# torchvision 0.26.0 + rocm7.1 (3.5 MB)  ← 0.26.0 配 torch 2.11.0
https://download.pytorch.org/whl/rocm7.1/torchvision-0.26.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl

# triton-rocm 3.6.0 (300 MB)  ← 注意是 triton-rocm 不是 pytorch-triton-rocm
https://download.pytorch.org/whl/triton_rocm-3.6.0-cp313-cp313-linux_x86_64.whl
```

**aria2c 加速**（推荐 4-8 并发）：

```bash
aria2c -j 4 -s 4 -x 4 \
  "https://download.pytorch.org/whl/rocm7.1/torch-2.11.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl"

# 离线装：pip install --no-deps --no-index --find-links /path/to/wheels/
```

## GitHub 国内镜像

```text
# GitHub 文件直链
https://gh-proxy.com/https://github.com/<user>/<repo>/archive/refs/heads/main.tar.gz
https://gh-proxy.com/https://github.com/<user>/<repo>/archive/refs/tags/v0.21.1rc0.tar.gz

# Raw 文件
https://gh-proxy.com/https://raw.githubusercontent.com/<user>/<repo>/<branch>/<file>

# git clone (HTTPS 协议)
GIT_CLONE_PROXY=https://gh-proxy.com git clone https://github.com/<user>/<repo>.git
```

**git config 全局替换**（让 git 自动用镜像）：

```bash
git config --global url."https://gh-proxy.com/https://github.com/".insteadOf "https://github.com/"
```

⚠️ **重要警告**：cmake `FetchContent` 模块调用的 git clone **不遵守** `insteadOf` 配置。
**必须手动预克隆**到 FetchContent 目录（通常是 `<build>/_deps/<name>-src/`）：

```bash
# 例如 vllm 编译时 FetchContent 要拉 triton_kernels
mkdir -p /root/vllm_build/_deps
cd /root/vllm_build/_deps
git clone --depth 1 --branch v3.5.1 \
  https://gh-proxy.com/https://github.com/triton-lang/triton.git triton_kernels-src
# 然后 FetchContent 会检测到已存在，跳过下载
```

## ROCm apt 源

```bash
# 22.04 jammy
echo 'deb [arch=amd64] https://repo.radeon.com/rocm/apt/7.1.1 jammy main' | \
  sudo tee /etc/apt/sources.list.d/rocm.list

# 国内无镜像，必须直连。但用 aria2c 加速 apt 下载
```

**apt 用 aria2c 加速下载**：

```bash
# 1. apt 给出 URL
apt-get install -y --print-uris --no-install-recommends <pkg>

# 2. 输出转为 aria2 input file
# URL 在 'https://...' 那一行，下载到 /var/cache/apt/archives/

# 3. aria2c -j 8 -s 8 -x 8 -i <input-file>
```

详见 `scripts/gen_aria2_input.sh`（如果 skill 提供）。

## HuggingFace / Modelscope

```bash
# 走 ModelScope（国内快 5-10x）
export MINERU_MODEL_SOURCE=modelscope
# 或
export HF_ENDPOINT=https://hf-mirror.com
```

**MinerU 用 ModelScope 模型路径**：

```json
{
    "models-dir": {
        "pipeline": "/mnt/c/Users/<user>/.cache/modelscope/models/OpenDataLab--PDF-Extract-Kit-1.0/snapshots/master",
        "vlm": ""
    },
    "model-source": "modelscope"
}
```

## cmake 镜像

```bash
# cmake 直接走 pip 装（USTC 镜像 25 MB/s）
pip install cmake -i https://mirrors.ustc.edu.cn/pypi/web/simple/

# 装到 /usr/local/bin 让 setup.py 找到
cp ~/mineru_stable/.venv/bin/cmake /usr/local/bin/cmake
chmod +x /usr/local/bin/cmake
cmake --version  # 4.0+
```

⚠️ **不要用 `sudo snap install cmake --classic`**：snapd 依赖 systemd mount namespace，
WSL2 内核中受限，命令**永久阻塞**。

## Docker（备选）

如果嫌麻烦，教程作者也提供 Docker 镜像（在 `buptanswer/mineru` GitHub）：

```bash
docker pull buptanswer/mineru:latest
docker run --rm -it --device=/dev/kfd --device=/dev/dxg \
  -v /mnt/c:/mnt/c -v /mnt/d:/mnt/d buptanswer/mineru:latest
```

但 Docker 镜像**不包含** WSL2 桥接的 librocdxg，**只能原生 Linux 用**。
