# 32 项踩坑清单（AMD + WSL2 路径）

源自 `buptanswer/mineru` GitHub 教程 11 步 + 实测补充。每条都标注"症状 / 原因 / 解决"。

## A. 环境准备

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 1 | WSL2 默认是 Ubuntu 24.04，apt 装 ROCm 7.1.1 后 vllm cmake 报 FP8 错误 | LLVM 20 与 ROCm 7.1.1 头文件不兼容 | 装 Ubuntu 22.04（教程唯一支持组合） |
| 2 | `sudo snap install cmake --classic` 卡死无输出 | snapd 依赖 systemd mount namespace，WSL2 内核受限 | 用 `pip install cmake -i USTC mirror`，或 Kitware 二进制 |
| 3 | WSL2 重启后 GPU 不可见 | `HSA_ENABLE_DXG_DETECTION=1` 没加载；DNS 重置 | `source /etc/profile.d/rocm.sh`；写 `/etc/resolv.conf` nameserver 8.8.8.8 |
| 4 | `cmake --version` 还是 3.22.1 | `snap install cmake` 没成功但你以为是 OK | 用 `pip install cmake` 然后 `cp ~/mineru_stable/.venv/bin/cmake /usr/local/bin/` |
| 5 | `python3.13` 找不到 | 22.04 默认 Python 3.10 | `add-apt-repository ppa:deadsnakes/ppa && apt install python3.13 python3.13-venv python3.13-dev` |

## B. ROCm 7.1.1 安装

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 6 | apt 装 ROCm 包 30 分钟没完 | repo.radeon.com 国内 15 KB/s | aria2c -j 8 拉 .deb，dpkg -i |
| 7 | `rocminfo` 报 "ROCk module NOT loaded" | Ubuntu 自带 rocminfo 5.0.0 太旧，缺 WSL2 桥接 | `apt install --allow-downgrades rocminfo=1.0.0.70101-38~22.04` |
| 8 | `rocminfo` 不显示 GPU（只有 CPU） | `HSA_ENABLE_DXG_DETECTION=1` 没设；librocdxg 没编译 | 跑 `status.sh` 自动诊断 |
| 9 | apt update 时 `repository does not have a Release file` (USTC Kitware) | USTC Kitware 镜像无 Release | 不要加这个源，直接 `pip install cmake` |

## C. ROCm dev 包（vllm 编译需要）

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 10 | vllm cmake 报 `roc::hipsparselt target not found` | 漏 `hipsparselt-dev` | `apt install hipsparselt-dev` |
| 11 | vllm cmake 报 `Could not find a package configuration file provided by "miopen"` | 漏 `miopen-hip-dev` | `apt install miopen-hip-dev` |
| 12 | vllm cmake 报 `Could not find a package configuration file provided by "rocsolver"` | 漏 `rocsolver-dev` | `apt install rocsolver-dev` |
| 13 | vllm cmake 报 `Could not find a package configuration file provided by "hipblaslt"` | 漏 `hipblaslt-dev` | `apt install hipblaslt-dev` |
| 14 | **不要符号链接** `hipblas.h → rocblas.h` | rocblas.h 内部有相对路径 `#include "internal/..."` | 装真包：`apt install hipblas-dev` |

## D. PyTorch 安装

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 15 | `Found 0 rocprofiler agents` | PyTorch 2.12+ 默认集成 rocprofiler，WSL2 没 KFD | 降回 2.11.0+rocm7.1 |
| 16 | `pip install` 自动装 torchvision 0.27+rocm7.1（要 torch 2.12） | METADATA 硬编码 | `pip install --no-deps --no-index --find-links /wheels/` |
| 17 | `triton` 找不到 / `triton-rocm` 找不到 | 教程写错包名 | 用 `triton-rocm==3.6.0`（不是 `pytorch-triton-rocm==3.2.0`） |
| 18 | `torch.cuda.is_available()` 返回 False | `HSA_ENABLE_DXG_DETECTION=1` 没设；librocdxg 没装 | 检查 `/opt/rocm/lib/librocdxg.so*`；source /etc/profile.d/rocm.sh |

## E. vLLM 编译

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 19 | cmake 报 "Failed to find ROCm root directory" | `PATH` 没包含 `/opt/rocm/bin`（cmake 调 hipconfig） | `export PATH=/opt/rocm/bin:/opt/rocm/llvm/bin:$PATH` |
| 20 | cmake 报 "Failed to find a default HIP architecture" | WSL2 中 `rocm_agent_enumerator` 失效 | 显式 `-DCMAKE_HIP_ARCHITECTURES=gfx1100` |
| 21 | cmake 报 `CMAKE_HIP_COMPILER ... refusing` | 用了 `-DCMAKE_HIP_COMPILER=hipcc` | **不要**设这个，CMake 4.0 拒绝 Perl 包装器 |
| 22 | ninja 编译 `exit 137` (OOM) | 16GB 内存开 -j20 | `ninja -j4`（或 -j2） |
| 23 | `pip install -e .` cmake 缺 `HIP_ROOT_DIR` | setup.py 只读 `ROCM_HOME` 设 `-DROCM_PATH` | `export CMAKE_ARGS="-DHIP_ROOT_DIR=/opt/rocm -DCMAKE_HIP_ARCHITECTURES=gfx1100"` |
| 24 | `pip install -e .` 触发 FetchContent git clone triton_kernels 0.3 MB/s | FetchContent 不遵守 git `insteadOf` | 手动用 gh-proxy 预克隆到 `/root/vllm/.deps/triton_kernels-src` |
| 25 | ninja 启动后只完成 step 1 (hipify) 不继续 | 上次 main 编译的 .abi3.so 还在，ninja 检测 .hip 旧但不动 | `rm -rf vllm_build` 后重 cmake + ninja |
| 26 | `Successfully installed vllm-...` 但 `import vllm` 失败 | setuptools-scm 没读到版本 | `git init && git add -A && git commit` 在 vllm 目录里 |

## F. vLLM platform patch (9.10)

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 27 | `from vllm.platforms import current_platform` 报 `Device string must not be empty` | amdsmi 在 WSL2 失败 → vllm 误判 | 改 `vllm/platforms/__init__.py` 加 `torch.version.hip` fallback |
| 28 | `NotImplementedError`，提示 `UnspecifiedPlatform.check_if_supports_dtype` | `rocm.py` 中 `logger.warning_once()` 触发循环导入 | 改 `vllm/platforms/rocm.py` 把 `logger.warning_once(...)` 换成 `sys.stderr.write(...)` |
| 29 | 改完 patch 还是 `ImportError: cannot import name '_ON_GFX942'` | 旧教程用宽松正则误改模块级常量 | **只替换 except 块**，不要做整段函数替换 |

## G. MinerU + MIOpen patch

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 30 | `pip install mineru[core]` 后 `torch` 被覆盖成 `+cu126` | uv pip 激进依赖解析 | 用原生 `pip`，**不用 `uv pip`** |
| 31 | MIOpen 冷启动每页 1-7s 延迟 | RDNA 上 MIOpen 遇新尺寸卷积搜 kernel | 教程 12 步 `cache_warmer.py` 预热（944 个尺寸 ~3-4 分钟） |
| 32 | `predict_det.py` 缩进报错 | mineru 3.4.4 的 `inp.to(self.device)` 是 **12 spaces**，不是教程默认 16 | patch 脚本已处理；详见 `scripts/patch-mineru-miopen.py` |

## H. 其它

| # | 症状 | 原因 | 解决 |
|---|---|---|---|
| 33 | WSL2 重启后 `rocm-smi` 找不到 | Windows 端 AMD 驱动被 Windows Update 重装 | 重新装 Windows AMD 驱动，重启 WSL |
| 34 | 第一次跑某 PDF 报 "MIOpen: no kernel found" | gfx1102 等中端卡 ROCm 运行时未识别 | `export HSA_OVERRIDE_GFX_VERSION=11.0.0`（伪装成 7900 XTX） |
| 35 | `mineru --help` 报 `KeyError: 'pipeline'` | mineru.json 路径错 | 检查 `models-dir.pipeline` 是 **snapshots/master**（不是 snapshots 父目录） |
| 36 | `mineru` 跑时报 "libhsa-runtime64.so.1: cannot open" | librocdxg 没装 | `sudo make install` + `sudo ldconfig` |
