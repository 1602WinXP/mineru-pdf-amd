# PyTorch + torchvision + triton wheel 配对矩阵

**最重要**：`pip install` 默认按 METADATA 解析依赖。torchvision / triton / vllm 包的
`Requires-Dist: torch==X.Y.Z` 是硬编码的，**装错版本**会被覆盖成最新可用版本，导致
教程指定的 torch 2.11.0 被换成 2.12.0，然后 WSL2 闪退 `Found 0 rocprofiler agents`。

## 当前可用配对（cp313 + rocm7.1，2026-07）

| torch | torchvision | pytorch-triton-rocm | triton-rocm | 备注 |
|---|---|---|---|---|
| 2.10.0 | 0.25.0 | (3.2.0) | - | 旧 |
| **2.11.0** | **0.26.0** | (3.2.0) | **3.6.0** | ✅ 教程指定 |
| 2.12.0 | 0.27.0 / 0.27.1 | - | 3.7.0 / 3.7.1 | WSL2 闪退 |
| 2.12.0+ | 0.28.0 | - | - | WSL2 闪退 |

⚠️ **两个不同的包**：
- `pytorch-triton-rocm==3.2.0` (PyPI 名: pytorch_triton_rocm) — **旧版** torch 1.x 时代
- `triton-rocm==3.6.0` (PyPI 名: triton_rocm) — **新版** torch 2.11+ 要求

教程原文（GitHub README）写的是 `pytorch-triton-rocm` 是**错误**的。torch 2.11+ METADATA
要求的是 `triton-rocm==3.6.0`。

## 安装命令

```bash
# 必须用 --no-deps --no-index --find-links 绕过 METADATA 检查
pip install --no-deps --no-index --find-links /root/wheels/ \
    torch==2.11.0+rocm7.1 \
    torchvision==0.26.0+rocm7.1 \
    triton-rocm==3.6.0
```

## 验证安装正确

```bash
python -c "
import torch
print('PyTorch:', torch.__version__)  # 必须 2.11.0+rocm7.1
print('HIP:', torch.version.hip)        # 必须 7.1.x
print('CUDA available:', torch.cuda.is_available())  # 必须 True
print('Device:', torch.cuda.get_device_name(0))  # 必须 AMD Radeon RX ...
x = torch.randn(100, 100).cuda()
print('Test matmul:', (x @ x).shape)  # 必须 PASS
"
```

## 关键 URL

| 包 | URL 模板 |
|---|---|
| torch | `https://download.pytorch.org/whl/rocm7.1/torch-2.11.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl` |
| torchvision | `https://download.pytorch.org/whl/rocm7.1/torchvision-0.26.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl` |
| triton-rocm | `https://download.pytorch.org/whl/triton_rocm-3.6.0-cp313-cp313-linux_x86_64.whl` |

URL 中 `+` 必须 URL-encode 为 `%2B`，`manylinux_2_28` 是 cp313 wheel 的标准 tag。

## vLLM 版本配对

| vLLM | commit/tag | 与教程的兼容性 |
|---|---|---|
| 0.21.1rc0 | `v0.21.1rc0` tag | ✅ 教程指定 |
| 0.21.1rc1 | **不存在** (GitHub tag 列表) | — |
| 0.21.0 | `v0.21.0` tag | 可用但教程用 rc0 |
| `357fddf61` (旧 commit) | git checkout | 旧教程，已弃用 PEP 639 |
| latest `main` | — | ❌ setup.py 缺 HIP_ROOT_DIR bug |

**用 v0.21.1rc0**（GitHub tag）。教程 README 写 0.21.1rc1 是错的（该 tag 不存在）。

```bash
curl -L https://gh-proxy.com/https://github.com/vllm-project/vllm/archive/refs/tags/v0.21.1rc0.tar.gz \
  -o vllm-v0.21.1rc0.tar.gz
tar -xzf vllm-v0.21.1rc0.tar.gz
mv vllm-v0.21.1rc0 vllm

# setuptools-scm 需要 .git
cd vllm && git init && git add -A && git commit -m 'init' --no-verify
```

## MinerU 版本

| MinerU | 状态 | 备注 |
|---|---|---|
| 3.4.4 | ✅ 最新 stable | 教程用 |
| 3.2.0 | 旧 | GitHub README 教程用 |
| 3.1.15 | 旧 | 早期教程 |

**用 3.4.4**（pip install mineru[core] 默认装最新）。
