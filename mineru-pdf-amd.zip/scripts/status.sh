#!/bin/bash
# status.sh — 验证 AMD + WSL2 + MinerU 环境就绪
# 用法: bash status.sh

set -e
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok() { echo -e "${GREEN}✓${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; }
warn() { echo -e "${YELLOW}!${NC} $1"; }

echo "========================================"
echo "MinerU AMD 环境状态"
echo "========================================"

# 1. WSL2 系统
if grep -q "22.04" /etc/os-release 2>/dev/null; then
    ok "Ubuntu 22.04 (jammy)"
else
    fail "Ubuntu 不是 22.04（教程不支持 24.04 + ROCm 7.1.1）"
    cat /etc/os-release | head -3
    exit 1
fi

# 2. ROCm 7.1.1
if [ -d "/opt/rocm-7.1.1" ] || [ -d "/opt/rocm" ]; then
    ROCM_VER=$(ls /opt/rocm-*/share/rocm/version 2>/dev/null | head -1)
    if [ -f "$ROCM_VER" ]; then
        V=$(cat "$ROCM_VER")
        if [[ "$V" == 7.1.1* ]]; then
            ok "ROCm $V"
        else
            warn "ROCm $V (教程用 7.1.1)"
        fi
    else
        ok "ROCm 目录存在（version 文件未找到）"
    fi
else
    fail "ROCm 未安装"
    exit 1
fi

# 3. librocdxg
if [ -f "/opt/rocm/lib/librocdxg.so" ] || [ -f "/opt/rocm/lib/librocdxg.so.1.2.1" ]; then
    ok "librocdxg 已编译"
else
    fail "librocdxg 未编译（WSL2 桥接必需）"
fi

# 4. HSA env
if [ -n "$HSA_ENABLE_DXG_DETECTION" ]; then
    ok "HSA_ENABLE_DXG_DETECTION=$HSA_ENABLE_DXG_DETECTION"
else
    warn "HSA_ENABLE_DXG_DETECTION 未设（GPU 可能不可见）"
fi

# 5. GPU 可见
echo ""
echo "--- GPU 检测 ---"
if command -v /opt/rocm/bin/rocminfo &> /dev/null; then
    GPU=$(/opt/rocm/bin/rocminfo 2>/dev/null | grep -A 1 "Agent 2" | grep "Marketing Name" | awk '{print $3,$4,$5,$6}')
    if [ -n "$GPU" ]; then
        ok "GPU: $GPU"
    else
        fail "rocminfo 未识别 GPU"
    fi
else
    fail "rocminfo 不在 PATH"
fi

# 6. Python venv
VENV="$HOME/mineru_stable/.venv"
if [ -f "$VENV/bin/python" ]; then
    ok "Python venv: $VENV"
else
    fail "venv 不存在: $VENV"
    exit 1
fi

# 7. PyTorch
echo ""
echo "--- PyTorch ---"
TORCH_VER=$($VENV/bin/python -c "import torch; print(torch.__version__)" 2>/dev/null || echo "未安装")
if [[ "$TORCH_VER" == *"rocm7.1"* ]]; then
    ok "PyTorch $TORCH_VER"
else
    fail "PyTorch $TORCH_VER (应含 +rocm7.1)"
fi

HIP_VER=$($VENV/bin/python -c "import torch; print(torch.version.hip)" 2>/dev/null)
ok "HIP $HIP_VER"

CUDA_AVAIL=$($VENV/bin/python -c "import torch; print(torch.cuda.is_available())" 2>/dev/null)
if [ "$CUDA_AVAIL" = "True" ]; then
    ok "CUDA available: True"
    DEVICE=$($VENV/bin/python -c "import torch; print(torch.cuda.get_device_name(0))" 2>/dev/null)
    ok "Device: $DEVICE"
else
    fail "CUDA available: False (GPU 不可用)"
fi

# 8. torchvision
TV_VER=$($VENV/bin/python -c "import torchvision; print(torchvision.__version__)" 2>/dev/null || echo "未安装")
if [[ "$TV_VER" == *"0.26"* ]]; then
    ok "torchvision $TV_VER"
else
    warn "torchvision $TV_VER (教程用 0.26.0+rocm7.1)"
fi

# 9. triton-rocm
TR_VER=$($VENV/bin/python -c "import triton; print(triton.__version__)" 2>/dev/null || echo "未安装")
ok "triton $TR_VER"

# 10. vLLM
echo ""
echo "--- vLLM ---"
if $VENV/bin/python -c "import vllm" 2>/dev/null; then
    ok "vllm 已装"
    PLATFORM=$($VENV/bin/python -c "from vllm.platforms import current_platform; print(type(current_platform).__name__)" 2>/dev/null)
    if [ "$PLATFORM" = "RocmPlatform" ]; then
        ok "Platform: $PLATFORM"
    else
        warn "Platform: $PLATFORM (期望 RocmPlatform，需打 9.10 patch)"
    fi
else
    fail "vllm 未装"
fi

# 11. MinerU
echo ""
echo "--- MinerU ---"
MINERU_VER=$($VENV/bin/mineru --version 2>/dev/null | awk '{print $NF}' || echo "未安装")
if [[ "$MINERU_VER" == "3.4.4" ]]; then
    ok "MinerU $MINERU_VER"
else
    warn "MinerU $MINERU_VER (教程用 3.4.4)"
fi

# 12. mineru.json
if [ -f "$HOME/mineru.json" ]; then
    ok "mineru.json: $HOME/mineru.json"
    PIPELINE=$($VENV/bin/python -c "import json; print(json.load(open('$HOME/mineru.json'))['models-dir']['pipeline'])" 2>/dev/null)
    if [ -d "$PIPELINE" ]; then
        ok "  pipeline 路径存在: $PIPELINE"
    else
        warn "  pipeline 路径不存在: $PIPELINE"
    fi
else
    warn "mineru.json 不存在: $HOME/mineru.json"
fi

# 13. 算力测试
echo ""
echo "--- GPU 算力测试 ---"
RESULT=$($VENV/bin/python -c "
import torch
x = torch.randn(100, 100).cuda()
y = x @ x
print(f'shape={tuple(y.shape)}')
" 2>&1)
if [[ "$RESULT" == *"PASS"* ]] || [[ "$RESULT" == *"shape="* ]]; then
    ok "GPU matmul: $RESULT"
else
    fail "GPU matmul 失败: $RESULT"
fi

echo ""
echo "========================================"
echo "Status check done"
echo "========================================"
