#!/bin/bash
# start_api.sh — 启动长连接 mineru-api
# 用法: bash start_api.sh [port]  (默认 8000)

set -e
PORT=${1:-8000}
MINERU_HOME=${MINERU_HOME:-$HOME/mineru_stable}
API_LOG=/tmp/mineru-api-${PORT}.log
PID_FILE=/tmp/mineru-api-${PORT}.pid

# 加载 ROCm env
source /etc/profile.d/rocm.sh 2>/dev/null || true

# 检查已运行
if [ -f "$PID_FILE" ] && kill -0 $(cat $PID_FILE) 2>/dev/null; then
    echo "API 已在运行: PID=$(cat $PID_FILE) port=$PORT"
    echo "URL: http://127.0.0.1:$PORT"
    exit 0
fi

# 检查 mineru 装好
if [ ! -f "$MINERU_HOME/.venv/bin/mineru-api" ]; then
    echo "ERROR: mineru-api 不存在 ($MINERU_HOME/.venv/bin/mineru-api)"
    echo "请先跑 bootstrap_install.sh"
    exit 1
fi

# 检查 port
if ss -tln 2>/dev/null | grep -q ":$PORT "; then
    echo "ERROR: port $PORT 已被占用"
    echo "用 stop_api.sh 关掉旧实例或换 port"
    exit 1
fi

# 启动
echo "启动 mineru-api at port $PORT ..."
nohup $MINERU_HOME/.venv/bin/mineru-api \
    --host 127.0.0.1 --port $PORT \
    > $API_LOG 2>&1 &

PID=$!
echo $PID > $PID_FILE

# 等启动
for i in {1..30}; do
    if curl -sf http://127.0.0.1:$PORT/health >/dev/null 2>&1 || \
       curl -sf http://127.0.0.1:$PORT/ >/dev/null 2>&1 || \
       curl -sf http://127.0.0.1:$PORT/docs >/dev/null 2>&1; then
        echo "API ready: http://127.0.0.1:$PORT (PID=$PID)"
        echo "日志: $API_LOG"
        exit 0
    fi
    sleep 1
done

echo "WARNING: API 60s 内未响应（可能仍在启动）"
echo "日志: $API_LOG"
echo "PID: $PID (在 $PID_FILE)"
exit 1
