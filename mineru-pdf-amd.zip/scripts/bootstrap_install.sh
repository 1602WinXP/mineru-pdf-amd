#!/bin/bash
# bootstrap_install.sh — AMD + WSL2 + MinerU 一键安装
# 严格按 buptanswer/mineru 教程 11 步（路径 A: 22.04 + 7.1.1）
# 总耗时 2-3 小时（含 vllm 编译 30-60 min）

set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WHEELS_DIR="$HOME/wheels"
MINERU_HOME="$HOME/mineru_stable"
PYTHON_VERSION="3.13"
PYTORCH_VERSION="2.11.0+rocm7.1"
TORCHVISION_VERSION="0.26.0+rocm7.1"
TRITON_VERSION="3.6.0"
VLLM_VERSION="v0.21.1rc0"
ROCM_VERSION="7.1.1"
GFX_ARCH="${GFX_ARCH:-gfx1100}"  # 7900 XTX 默认; 9070 用 gfx1201

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'
log() { echo -e "${GREEN}[$(date +%H:%M:%S)]${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +%H:%M:%S)] WARN:${NC} $1"; }
die() { echo -e "${RED}[$(date +%H:%M:%S)] ERROR:${NC} $1"; exit 1; }

# 检查 Ubuntu 22.04
if ! grep -q "22.04" /etc/os-release 2>/dev/null; then
    die "Ubuntu 22.04 必需。当前系统是: $(grep PRETTY_NAME /etc/os-release)"
fi
log "Ubuntu 22.04 ✓"

# 检查 AMD GPU
if ! /opt/rocm/bin/rocminfo 2>/dev/null | grep -q "AMD Radeon"; then
    warn "未检测到 AMD GPU（继续安装但可能跑不通）"
fi

# =================================================================
# Step 1: 基础依赖
# =================================================================
log "Step 1: 基础依赖..."
sudo DEBIAN_FRONTEND=noninteractive apt update -y
sudo DEBIAN_FRONTEND=noninteractive apt install -y \
    build-essential git wget curl aria2 \
    software-properties-common \
    python3.13 python3.13-venv python3.13-dev \
    libnuma-dev libdrm2 libhwloc-dev libgl1-mesa-glx \
    ninja-build pkg-config

# deadsnakes PPA for Python 3.13 (22.04 默认 3.10)
if ! command -v python3.13 &>/dev/null; then
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo DEBIAN_FRANTEND=noninteractive apt update -y
    sudo DEBIAN_FRONTEND=noninteractive apt install -y python3.13 python3.13-venv python3.13-dev
fi

# cmake 4.0+（教程 9.4 要求；snap 不能用）
if ! command -v cmake &>/dev/null || [[ "$(cmake --version | head -1 | awk '{print $3}')" < "4.0" ]]; then
    log "安装 cmake 4.4 (USTC pip mirror)..."
    if [ ! -d "$MINERU_HOME/.venv" ]; then
        mkdir -p $MINERU_HOME
        python3.13 -m venv $MINERU_HOME/.venv
    fi
    $MINERU_HOME/.venv/bin/pip install cmake -i https://mirrors.ustc.edu.cn/pypi/web/simple/ 2>&1 | tail -3
    sudo cp $MINERU_HOME/.venv/bin/cmake /usr/local/bin/
    sudo chmod +x /usr/local/bin/cmake
fi
log "Step 1 ✓"

# =================================================================
# Step 2: ROCm 7.1.1
# =================================================================
log "Step 2: ROCm $ROCM_VERSION..."
if [ ! -d "/opt/rocm-7.1.1" ]; then
    wget -q https://repo.radeon.com/rocm/rocm.gpg.key -O- | \
        sudo gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/rocm.gpg > /dev/null
    echo "deb [arch=amd64] https://repo.radeon.com/rocm/apt/$ROCM_VERSION jammy main" | \
        sudo tee /etc/apt/sources.list.d/rocm.list
    sudo apt update
    sudo DEBIAN_FRONTEND=noninteractive apt install -y rocminfo hip-dev miopen-hip
    sudo DEBIAN_FRONTEND=noninteractive apt install -y --allow-downgrades \
        rocminfo=1.0.0.70101-38~22.04 \
        rocm-device-libs=1.0.0.70101-38~22.04
fi
log "Step 2 ✓"

# =================================================================
# Step 3: librocdxg (WSL2 桥接)
# =================================================================
log "Step 3: librocdxg (WSL2 桥接)..."
if [ ! -f /opt/rocm/lib/librocdxg.so ]; then
    SDK_DIR=$(ls -d /mnt/c/Program\ Files\ \(x86\)/Windows\ Kits/10/Include/10.0.* 2>/dev/null | head -1)
    if [ -z "$SDK_DIR" ]; then
        die "Windows SDK 未找到。请在 Windows 装 Windows 10/11 SDK"
    fi
    cd ~
    if [ ! -d librocdxg ]; then
        git clone https://gh-proxy.com/https://github.com/ROCm/librocdxg.git
    fi
    cd librocdxg
    mkdir -p build && cd build
    cmake .. "-DWIN_SDK=$SDK_DIR/shared"
    make -j$(nproc)
    sudo make install
    sudo sh -c 'echo /opt/rocm/lib > /etc/ld.so.conf.d/rocm.conf'
    sudo ldconfig
    sudo usermod -a -G render,video $USER
fi
log "Step 3 ✓"

# ROCm env
cat > /tmp/rocm_env.sh << 'EOF'
export HSA_ENABLE_DXG_DETECTION=1
export FLASH_ATTENTION_TRITON_AMD_ENABLE=TRUE
export TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL=1
export PYTORCH_ROCM_ARCH=gfx1100
export PATH=/opt/rocm/bin:/opt/rocm/llvm/bin:$PATH
export LD_LIBRARY_PATH=/opt/rocm/lib:$LD_LIBRARY_PATH
EOF
sudo cp /tmp/rocm_env.sh /etc/profile.d/rocm.sh
sudo chmod +x /etc/profile.d/rocm.sh
source /etc/profile.d/rocm.sh
log "Step 3 env ✓"

# =================================================================
# Step 3.5: ROCm dev 包
# =================================================================
log "Step 3.5: ROCm dev 包..."
for pkg in hipblas-dev hiprand-dev hipsparse-dev hipsparselt-dev hipsolver-dev \
           hipcub-dev rocprim-dev rocthrust-dev rocblas-dev rocrand-dev \
           hipfft-dev hipblaslt miopen-hip-dev rocsolver-dev rocsparse-dev \
           roctracer-dev; do
    if ! dpkg -l | grep -q "^ii  $pkg "; then
        log "  装 $pkg"
        sudo DEBIAN_FRONTEND=noninteractive apt install -y $pkg 2>/dev/null || \
            warn "  装 $pkg 失败（可能不存在）"
    fi
done
log "Step 3.5 ✓"

# =================================================================
# Step 4: Python venv + PyTorch
# =================================================================
log "Step 4: Python venv + PyTorch..."
if [ ! -d "$MINERU_HOME/.venv" ]; then
    mkdir -p $MINERU_HOME
    python3.13 -m venv $MINERU_HOME/.venv
fi
source $MINERU_HOME/.venv/bin/activate

mkdir -p $WHEELS_DIR
cd $WHEELS_DIR
if [ ! -f "torch-${PYTORCH_VERSION}-cp313-cp313-manylinux_2_28_x86_64.whl" ]; then
    log "  aria2c 拉 torch (5.8GB)..."
    aria2c -j 4 -s 4 -x 4 \
        "https://download.pytorch.org/whl/rocm7.1/torch-2.11.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl"
fi
if [ ! -f "torchvision-0.26.0+rocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl" ]; then
    log "  aria2c 拉 torchvision..."
    aria2c -j 4 -s 4 -x 4 \
        "https://download.pytorch.org/whl/rocm7.1/torchvision-0.26.0%2Brocm7.1-cp313-cp313-manylinux_2_28_x86_64.whl"
fi
if [ ! -f "triton_rocm-3.6.0-cp313-cp313-linux_x86_64.whl" ]; then
    log "  aria2c 拉 triton-rocm..."
    aria2c -j 4 -s 4 -x 4 \
        "https://download.pytorch.org/whl/triton_rocm-3.6.0-cp313-cp313-linux_x86_64.whl"
fi

# 离线装（绕开 METADATA 错位）
pip install --no-deps --no-index --find-links $WHEELS_DIR/ \
    torch==${PYTORCH_VERSION} torchvision==${TORCHVISION_VERSION} triton-rocm==${TRITON_VERSION}

# 基础 deps
pip install -i https://mirrors.ustc.edu.cn/pypi/web/simple/ \
    filelock typing_extensions sympy networkx jinja2 fsspec mpmath \
    'numpy<2' pillow MarkupSafe 'setuptools<82'
log "Step 4 ✓"

# =================================================================
# Step 5: vLLM 编译
# =================================================================
log "Step 5: vLLM $VLLM_VERSION 编译 (30-60 min)..."
if ! python -c "import vllm" 2>/dev/null; then
    cd ~
    if [ ! -d vllm ]; then
        if [ ! -f vllm-${VLLM_VERSION}.tar.gz ]; then
            log "  下载 vllm tarball (34MB)..."
            curl -L --max-time 300 -o vllm-${VLLM_VERSION}.tar.gz \
                "https://gh-proxy.com/https://github.com/vllm-project/vllm/archive/refs/tags/${VLLM_VERSION}.tar.gz"
        fi
        tar -xzf vllm-${VLLM_VERSION}.tar.gz
        mv vllm-${VLLM_VERSION#v} vllm
        cd vllm
        git init -q && git add -A && git commit -q -m "init" --no-verify
    else
        cd vllm
    fi

    # setuptools + build deps
    pip install -U 'setuptools>=77.0.3' setuptools_scm setuptools_rust wheel -i https://mirrors.ustc.edu.cn/pypi/web/simple/ || true
    pip install 'setuptools<82' -i https://mirrors.ustc.edu.cn/pypi/web/simple/

    # cmake configure
    rm -rf ~/vllm_build 2>/dev/null || true
    mkdir -p ~/vllm_build
    cmake -S ~/vllm -B ~/vllm_build -G Ninja \
        -DCMAKE_BUILD_TYPE=RelWithDebInfo \
        -DVLLM_TARGET_DEVICE=rocm \
        -DVLLM_PYTHON_EXECUTABLE=$MINERU_HOME/.venv/bin/python \
        -DHIP_ROOT_DIR=/opt/rocm \
        -DROCM_PATH=/opt/rocm \
        -DCMAKE_HIP_ARCHITECTURES=$GFX_ARCH \
        -DCMAKE_PREFIX_PATH=$MINERU_HOME/.venv/lib/python3.13/site-packages/torch/share/cmake

    # ninja
    cd ~/vllm_build
    PYTORCH_ROCM_ARCH=$GFX_ARCH ninja -j4

    # 复制 .so 到 vllm 目录
    cp ~/vllm_build/*.abi3.so ~/vllm/vllm/

    # pip install -e (用 CMAKE_ARGS 注入 HIP_ROOT_DIR)
    cd ~/vllm
    export SETUPTOOLS_SCM_PRETEND_VERSION_FOR_VLLM=0.21.1rc0
    export VLLM_TARGET_DEVICE=rocm
    export PYTORCH_ROCM_ARCH=$GFX_ARCH
    export HIP_ROOT_DIR=/opt/rocm
    export ROCM_PATH=/opt/rocm
    export CMAKE_ARGS="-DHIP_ROOT_DIR=/opt/rocm -DCMAKE_HIP_ARCHITECTURES=$GFX_ARCH"
    pip install -e . --no-build-isolation --no-deps -i https://mirrors.ustc.edu.cn/pypi/web/simple/
fi
log "Step 5 ✓"

# =================================================================
# Step 6: vLLM platform patch
# =================================================================
log "Step 6: vLLM platform patch..."
if ! python -c "from vllm.platforms import current_platform; assert type(current_platform).__name__ == 'RocmPlatform'" 2>/dev/null; then
    python3 $SKILL_DIR/scripts/patch-vllm-platform.py
fi
log "Step 6 ✓"

# =================================================================
# Step 7: MinerU
# =================================================================
log "Step 7: MinerU 3.4.4..."
if [ -z "$(mineru --version 2>/dev/null | grep 3.4.4)" ]; then
    pip install 'mineru[core]' -i https://mirrors.ustc.edu.cn/pypi/web/simple/
fi
log "Step 7 ✓"

# =================================================================
# Step 8: MIOpen patch
# =================================================================
log "Step 8: MIOpen patch..."
python3 $SKILL_DIR/scripts/patch-mineru-miopen.py
log "Step 8 ✓"

# =================================================================
# Step 9: mineru.json
# =================================================================
log "Step 9: mineru.json..."
if [ ! -f $HOME/mineru.json ]; then
    cat > $HOME/mineru.json << 'EOF'
{
    "models-dir": {
        "pipeline": "/mnt/c/Users/<user>/.cache/modelscope/models/OpenDataLab--PDF-Extract-Kit-1.0/snapshots/master",
        "vlm": ""
    },
    "model-source": "modelscope",
    "config_version": "1.3.2"
}
EOF
    warn "  mineru.json 已创建。**必须**手动编辑 <user> 替换为 Windows 用户名！"
    warn "  参考: $HOME/mineru.json"
fi
log "Step 9 ✓"

echo ""
log "========================================"
log "✓ 全部 11 步完成"
log "========================================"
echo ""
log "下一步:"
echo "  1. 编辑 $HOME/mineru.json，把 <user> 替换为 Windows 用户名"
echo "  2. 验证: bash $SKILL_DIR/scripts/status.sh"
echo "  3. 测试 PDF: bash $SKILL_DIR/scripts/start_api.sh 8000"
echo "           python3 $SKILL_DIR/scripts/batch_process.py /path/to/pdfs /path/to/output"
echo "  4. 关闭 API: bash $SKILL_DIR/scripts/stop_api.sh"
