#!/bin/bash
# stop_api.sh — 停止长连接 mineru-api
# 用法: bash stop_api.sh [port]  (默认 8000)

set -e
PORT=${1:-8000}
PID_FILE=/tmp/mineru-api-${PORT}.pid

if [ ! -f "$PID_FILE" ]; then
    echo "No PID file at $PID_FILE"
    # Fallback: pkill
    pkill -f "mineru-api.*--port $PORT" 2>/dev/null || true
    exit 0
fi

PID=$(cat $PID_FILE)
if kill -0 $PID 2>/dev/null; then
    echo "Stopping mineru-api (PID=$PID)..."
    kill $PID
    sleep 2
    if kill -0 $PID 2>/dev/null; then
        kill -9 $PID
    fi
fi

rm -f $PID_FILE
echo "Stopped. Port $PORT freed."
