#!/usr/bin/env python3
"""mineru-pdf-amd skill - Batch PDF processor (AMD ROCm + WSL2).

Path resolution priority:
  1. $MINERU_HOME env var
  2. ~/mineru_stable (default)
  3. ~/mineru-portable
  4. ./mineru_stable (cwd-relative)

Usage:
    python batch_process.py <input_dir> <output_dir> [options]

Options:
    --api-url URL          mineru-api URL (default: http://127.0.0.1:8000)
    --concurrency N       parallel PDF processes (default: 2)
    --skip-blank          skip PDFs detected as blank
    --force               re-process even if SHA256 cache hit
    --backend {auto,pipeline,vlm,hybrid-auto-engine}  default: auto
    --method {auto,txt,ocr}                            default: auto
    --lang {ch,en,...}                                 default: ch

Examples:
    # Basic
    python batch_process.py ~/pdfs/ ~/out/ --skip-blank

    # Higher concurrency
    python batch_process.py ~/pdfs/ ~/out/ --concurrency 4

    # Force re-process
    python batch_process.py ~/pdfs/ ~/out/ --force
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional, Tuple

# ---- Path resolution ----
SCRIPT_DIR = Path(__file__).parent.resolve()
SKILL_DIR = SCRIPT_DIR.parent


def resolve_mineru_home() -> Optional[Path]:
    env = os.environ.get("MINERU_HOME")
    if env and Path(env).exists():
        return Path(env).resolve()
    candidates = [
        Path.home() / "mineru_stable",
        Path.home() / "mineru-portable",
        Path.cwd() / "mineru_stable",
    ]
    for c in candidates:
        if c.exists() and (c / ".venv" / "bin" / "mineru").exists():
            return c.resolve()
    return None


def find_mineru_cli(home: Path) -> Optional[Path]:
    """Locate the mineru CLI binary in the venv."""
    candidates = [
        home / ".venv" / "bin" / "mineru",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


# ---- PDF discovery ----
PDF_EXTS = {".pdf"}
SKIP_DIR_NAMES = {".batch_cache", "_archive", "_failed"}


def discover_pdfs(input_dir: Path) -> List[Path]:
    """Find all PDFs in input_dir (non-recursive on first level, recursive deeper)."""
    pdfs = []
    for p in sorted(input_dir.rglob("*.pdf")):
        if not any(parent.name in SKIP_DIR_NAMES for parent in p.parents):
            pdfs.append(p)
    return pdfs


# ---- SHA256 cache ----
def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def load_cache(output_dir: Path) -> dict:
    cf = output_dir / ".batch_cache.json"
    if cf.exists():
        try:
            return json.loads(cf.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_cache(output_dir: Path, cache: dict):
    cf = output_dir / ".batch_cache.json"
    cf.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")


# ---- Blank PDF detection ----
def is_blank_pdf(path: Path) -> bool:
    """Heuristic: check first 1MB of file for text content. If <1% non-whitespace, blank."""
    try:
        with path.open("rb") as f:
            data = f.read(1 << 20)
        text = data.decode("utf-8", errors="ignore")
        # Strip binary junk; keep only printable text
        printable = re.sub(r"[^\x20-\x7E\n\r\t]", "", text)
        if not printable.strip():
            return True
        # Heuristic: < 50 chars of printable text in 1MB = blank
        if len(printable.strip()) < 50:
            return True
        return False
    except Exception:
        return False


# ---- Process one PDF ----
def process_one(
    pdf: Path,
    output_dir: Path,
    mineru_home: Path,
    mineru_cli: Path,
    api_url: str,
    backend: str,
    method: str,
    lang: str,
    cache: dict,
    force: bool,
) -> Tuple[str, str, str, float]:
    """Returns (status, sha256, message, elapsed_sec)."""
    start = time.time()
    try:
        sha = sha256_file(pdf)
    except Exception as e:
        return ("error", "", f"sha256 failed: {e}", 0.0)

    if not force and cache.get(sha) == "ok":
        return ("cached", sha, "SHA256 hit", 0.0)

    # mineru CLI subprocess (subprocess mode is stable per skill rationale)
    out_dir = output_dir / pdf.stem
    out_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        str(mineru_cli),
        "-p", str(pdf),
        "-o", str(out_dir),
        "-b", backend,
        "-l", lang,
    ]
    if method != "auto":
        cmd.extend(["-m", method])
    if api_url:
        cmd.extend(["--api-url", api_url])

    env = os.environ.copy()
    env.setdefault("HSA_ENABLE_DXG_DETECTION", "1")
    env.setdefault("TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL", "1")

    try:
        result = subprocess.run(
            cmd,
            cwd=str(mineru_home),
            env=env,
            capture_output=True,
            text=True,
            timeout=600,  # 10 min per PDF
        )
        if result.returncode == 0:
            return ("ok", sha, "done", time.time() - start)
        return ("error", sha, f"exit {result.returncode}: {result.stderr[-300:]}", time.time() - start)
    except subprocess.TimeoutExpired:
        return ("error", sha, "timeout 600s", time.time() - start)
    except Exception as e:
        return ("error", sha, str(e), time.time() - start)


# ---- Main ----
def main():
    parser = argparse.ArgumentParser(
        description="Batch PDF processor for MinerU (AMD ROCm + WSL2)"
    )
    parser.add_argument("input_dir", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--api-url", default="http://127.0.0.1:8000")
    parser.add_argument("--concurrency", type=int, default=2)
    parser.add_argument("--skip-blank", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--backend", default="auto",
                        choices=["auto", "pipeline", "vlm", "hybrid-auto-engine"])
    parser.add_argument("--method", default="auto", choices=["auto", "txt", "ocr"])
    parser.add_argument("--lang", default="ch")
    args = parser.parse_args()

    # Pre-flight
    mineru_home = resolve_mineru_home()
    if mineru_home is None:
        print(f"[ERROR] mineru 未安装. 跑: bash {SKILL_DIR}/scripts/bootstrap_install.sh")
        sys.exit(1)
    mineru_cli = find_mineru_cli(mineru_home)
    if mineru_cli is None:
        print(f"[ERROR] mineru CLI not in {mineru_home}/.venv/bin/mineru")
        sys.exit(1)

    if not args.input_dir.is_dir():
        print(f"[ERROR] input_dir 不存在: {args.input_dir}")
        sys.exit(1)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    pdfs = discover_pdfs(args.input_dir)
    if not pdfs:
        print(f"[ERROR] 没找到 PDF in {args.input_dir}")
        sys.exit(1)
    print(f"找到 {len(pdfs)} 个 PDF in {args.input_dir}")

    # Blank detection
    skipped_blank = 0
    if args.skip_blank:
        non_blank = []
        for p in pdfs:
            if is_blank_pdf(p):
                skipped_blank += 1
                print(f"  [SKIP-blank] {p.name}")
            else:
                non_blank.append(p)
        pdfs = non_blank
        if skipped_blank:
            print(f"跳过 {skipped_blank} 个空白 PDF")

    # Cache
    cache = load_cache(args.output_dir)
    if args.force:
        cache = {}

    # Pre-flight: API health
    try:
        import urllib.request
        urllib.request.urlopen(args.api_url, timeout=5)
        print(f"API ok: {args.api_url}")
    except Exception as e:
        print(f"[WARN] API 不可达 ({args.api_url}): {e}")
        print(f"  跑: bash {SKILL_DIR}/scripts/start_api.sh 8000")

    # Process with concurrency
    print(f"\n开始处理 (concurrency={args.concurrency})...")
    results = {"ok": 0, "cached": 0, "error": 0}
    failed = []
    total_start = time.time()

    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futures = {
            ex.submit(
                process_one, pdf, args.output_dir, mineru_home, mineru_cli,
                args.api_url, args.backend, args.method, args.lang, cache, args.force
            ): pdf for pdf in pdfs
        }
        for i, fut in enumerate(as_completed(futures), 1):
            pdf = futures[fut]
            status, sha, msg, elapsed = fut.result()
            results[status] = results.get(status, 0) + 1
            if status == "ok":
                cache[sha] = "ok"
                print(f"  [{i}/{len(pdfs)}] OK  {elapsed:5.1f}s  {pdf.name}")
            elif status == "cached":
                print(f"  [{i}/{len(pdfs)}] CACHED         {pdf.name}")
            else:
                failed.append((pdf, msg))
                print(f"  [{i}/{len(pdfs)}] FAIL {elapsed:5.1f}s  {pdf.name}: {msg[:100]}")
            # Periodic cache save
            if i % 10 == 0:
                save_cache(args.output_dir, cache)

    save_cache(args.output_dir, cache)
    total_elapsed = time.time() - total_start

    # Report
    print()
    print("=" * 60)
    print(f"完成: {results.get('ok', 0)} ok / {results.get('cached', 0)} cached / {results.get('error', 0)} error")
    if skipped_blank:
        print(f"  + 跳过 {skipped_blank} 个空白")
    print(f"总耗时: {total_elapsed:.1f}s ({total_elapsed/60:.1f} min)")
    if results.get("ok", 0) > 0:
        print(f"平均/成功: {total_elapsed/results.get('ok', 0):.1f}s/PDF")
    if failed:
        print(f"\n失败 ({len(failed)}):")
        for pdf, msg in failed:
            print(f"  {pdf.name}: {msg[:120]}")
    print("=" * 60)


if __name__ == "__main__":
    main()
