#!/usr/bin/env python3
"""Apply WSL2 platform patches to vllm (buptanswer/mineru 教程 9.10 步骤).

Patches:
  1. vllm/platforms/__init__.py: rocm_platform_plugin() 加 torch.version.hip fallback
  2. vllm/platforms/rocm.py: _get_gcn_arch() except 块去 logger.warning_once

Run AFTER 'pip install -e .' succeeds.
"""
import re
import sys
from pathlib import Path

VLLM_DIR = Path.home() / "vllm" / "vllm" / "platforms"
INIT_PY = VLLM_DIR / "__init__.py"
ROCM_PY = VLLM_DIR / "rocm.py"


def patch_init():
    """补丁 A: rocm_platform_plugin() 加 torch.version.hip fallback"""
    src = INIT_PY.read_text(encoding="utf-8")
    if "WSL2 fallback: amdsmi doesn't work" in src:
        print(f"[SKIP] {INIT_PY} already patched")
        return
    old = (
        '    return "vllm.platforms.rocm.RocmPlatform" if is_rocm else None\n'
    )
    new = (
        "    # WSL2 fallback: amdsmi doesn't work, check torch.version.hip\n"
        "    if not is_rocm:\n"
        "        try:\n"
        "            import torch\n"
        "            if torch.version.hip is not None:\n"
        "                is_rocm = True\n"
        "        except Exception:\n"
        "            pass\n"
        '    return "vllm.platforms.rocm.RocmPlatform" if is_rocm else None\n'
    )
    if old not in src:
        print(f"[ERROR] {INIT_PY}: original rocm_platform_plugin return not found")
        sys.exit(1)
    INIT_PY.write_text(src.replace(old, new), encoding="utf-8")
    print(f"[OK] Patched {INIT_PY}")


def patch_rocm():
    """补丁 B: rocm.py _get_gcn_arch() except 块去 logger.warning_once"""
    src = ROCM_PY.read_text(encoding="utf-8")
    if "WSL2: amdsmi unavailable" in src:
        print(f"[SKIP] {ROCM_PY} already patched")
        return
    # Match the specific block; do NOT use a broad regex (would catch module-level constants)
    pattern = re.compile(
        r"    except Exception as e:\n"
        r"        logger\.debug\(\"Failed to get GCN arch via amdsmi: %s\", e\)\n"
        r"        logger\.warning_once\(\n"
        r"            \"Failed to get GCN arch via amdsmi, falling back to torch\.cuda\. \"\n"
        r"            \"This will initialize CUDA and may cause \"\n"
        r"            \"issues if CUDA_VISIBLE_DEVICES is not set yet\.\"\n"
        r"        \)"
    )
    new_block = (
        "    except Exception as e:\n"
        "        import sys as _sys\n"
        '        _sys.stderr.write("WSL2: amdsmi unavailable, using torch.cuda for GPU detection\\n")\n'
    )
    if not pattern.search(src):
        print(f"[ERROR] {ROCM_PY}: could not find the original except block")
        sys.exit(1)
    ROCM_PY.write_text(pattern.sub(new_block, src), encoding="utf-8")
    print(f"[OK] Patched {ROCM_PY}")


if __name__ == "__main__":
    if not VLLM_DIR.is_dir():
        print(f"[ERROR] vllm platforms dir not found: {VLLM_DIR}")
        print("Did you run 'pip install -e .' first?")
        sys.exit(1)
    patch_init()
    patch_rocm()
    print("All vllm platform patches applied.")
