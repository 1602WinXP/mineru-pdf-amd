#!/usr/bin/env python3
"""Apply RDNA MIOpen patches to MinerU 3.4.4 (buptanswer/mineru 教程 10.3).

Patches:
  1. predict_rec.py: imgW 32 像素对齐 + 批次填充
  2. predict_det.py: contiguous 连续性检查 (12-space indent in mineru 3.4.4)

Run AFTER 'pip install mineru[core]' succeeds.
"""
import ast
import re
import sys
from pathlib import Path

VENV = Path.home() / "mineru_stable" / ".venv"
MINERU_INFER = None
for p in VENV.glob("lib/python*/site-packages/mineru/model/utils/tools/infer"):
    MINERU_INFER = p
    break

if MINERU_INFER is None:
    print(f"[ERROR] mineru infer dir not found under {VENV}")
    print("Did you 'pip install mineru[core]'?")
    sys.exit(1)

print(f"Found mineru infer dir: {MINERU_INFER}")


def patch_rec():
    """predict_rec.py — imgW 32 像素对齐 + 批次填充"""
    p = MINERU_INFER / "predict_rec.py"
    src = p.read_text(encoding="utf-8")
    if "imgW = math.ceil(imgW / 32) * 32" in src:
        print(f"[SKIP] {p.name} already patched (imgW align)")
        return
    # Patch A: imgW alignment (8-space indent)
    pattern_a = re.compile(
        r"        imgW = max\(min\(imgW, self\.limited_max_width\), self\.limited_min_width\)\n"
    )
    if not pattern_a.search(src):
        print(f"[ERROR] {p.name}: imgW line not found")
        sys.exit(1)
    src = pattern_a.sub(
        "        imgW = max(min(imgW, self.limited_max_width), self.limited_min_width)\n"
        "        imgW = math.ceil(imgW / 32) * 32\n",
        src,
    )
    # Patch B: batch padding (16-space indent; mineru 3.4.4 wraps with np.ascontiguousarray)
    pattern_b = re.compile(
        r"                norm_img_batch = np\.ascontiguousarray\(np\.concatenate\(norm_img_batch\)\)\n"
    )
    if not pattern_b.search(src):
        print(f"[ERROR] {p.name}: concatenate line not found")
        sys.exit(1)
    src = pattern_b.sub(
        "                actual_batch_size = len(norm_img_batch)\n"
        "                if actual_batch_size < batch_num:\n"
        "                    pad_size = batch_num - actual_batch_size\n"
        "                    pad_img = np.zeros_like(norm_img_batch[0])\n"
        "                    for _ in range(pad_size):\n"
        "                        norm_img_batch.append(pad_img)\n"
        "                norm_img_batch = np.ascontiguousarray(np.concatenate(norm_img_batch))\n",
        src,
    )
    # Patch C: for loop range (20-space indent)
    pattern_c = re.compile(r"                for rno in range\(len\(rec_result\)\):\n")
    if pattern_c.search(src):
        src = pattern_c.sub("                for rno in range(actual_batch_size):\n", src)
    p.write_text(src, encoding="utf-8")
    print(f"[OK] Patched {p.name}")


def patch_det():
    """predict_det.py — contiguous 连续性检查 (12-space indent in mineru 3.4.4)"""
    p = MINERU_INFER / "predict_det.py"
    src = p.read_text(encoding="utf-8")
    if "if not inp.is_contiguous():" in src:
        print(f"[SKIP] {p.name} already patched (contiguous)")
        return
    # mineru 3.4.4 has inp.to(self.device) at 12-space indent
    # (not the 16-space default the tutorial assumed)
    old = (
        "            inp = inp.to(self.device)\n"
        "            inp = self._to_inference_dtype(inp)\n"
        "            outputs = self.net(inp)"
    )
    new = (
        "            inp = inp.to(self.device)\n"
        "            if not inp.is_contiguous():\n"
        "                inp = inp.contiguous()\n"
        "            inp = self._to_inference_dtype(inp)\n"
        "            outputs = self.net(inp)"
    )
    if old not in src:
        print(f"[ERROR] {p.name}: 12-space inp.to block not found")
        print("  (mineru version may differ; check the file manually)")
        sys.exit(1)
    src = src.replace(old, new, 1)
    p.write_text(src, encoding="utf-8")
    print(f"[OK] Patched {p.name}")


if __name__ == "__main__":
    patch_rec()
    patch_det()
    # Verify syntax
    for fname in ("predict_rec.py", "predict_det.py"):
        fp = MINERU_INFER / fname
        try:
            ast.parse(fp.read_text(encoding="utf-8"))
            print(f"  ✓ {fname} syntax OK")
        except SyntaxError as e:
            print(f"  ✗ {fname} syntax error: {e}")
            sys.exit(1)
    print("All MIOpen patches applied and verified.")
